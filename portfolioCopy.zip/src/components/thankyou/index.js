import React from 'react'

function ThankYou() {
  return (
    <div>ThankYou</div>
  )
}

export default ThankYou
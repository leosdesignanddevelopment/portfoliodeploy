import React from 'react'
import {Container} from 'react-bootstrap'
import '../../App.css'

import '../../css/landing.css'


function Landing() {
  return (
  <div className='main-content d-flex align-items-center  '>
  <Container>
       <p className='ms-5 '>A Portfolio</p>
      <h2 className='ms-5'>By: Omar Morales  </h2>

     

   
  </Container>
</div>
  )
}

export default Landing